import 'package:flutter/material.dart';

EdgeInsetsGeometry appSidePadding =
    const EdgeInsets.symmetric(horizontal: 18.0);
